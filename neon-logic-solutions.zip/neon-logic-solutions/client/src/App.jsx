
import { Phone, Globe, Code2 } from 'lucide-react'

export default function App() {
  return (
    <div
      className="min-h-screen bg-cover bg-center text-white"
      style={{
        backgroundImage:
          "url('https://images.unsplash.com/photo-1610041321327-b794d2268bbf?q=80&w=1920&auto=format&fit=crop')",
      }}
    >
      <div className="min-h-screen bg-black/70">
        <nav className="flex items-center justify-between px-10 py-6 border-b border-white/20">
          <h1 className="text-3xl font-bold text-cyan-400">
            Neon Logic Solutions
          </h1>

          <div className="space-x-6 text-lg">
            <a href="#services">Services</a>
            <a href="#about">About</a>
            <a href="#contact">Contact</a>
          </div>
        </nav>

        <section className="flex flex-col items-center justify-center text-center px-6 py-32">
          <h2 className="text-6xl font-extrabold leading-tight max-w-5xl">
            Building Modern Websites & Digital Solutions
          </h2>

          <p className="mt-6 text-xl max-w-3xl text-gray-200">
            Professional website development company based in Vrindavan.
          </p>
        </section>

        <section id="contact" className="px-10 py-20">
          <div className="max-w-3xl mx-auto bg-white/10 p-10 rounded-3xl border border-white/20 backdrop-blur-lg">
            <h2 className="text-4xl font-bold text-center text-cyan-400">
              Contact Us
            </h2>

            <div className="mt-8 text-xl space-y-5 text-center">
              <p>📍 Vrindavan, Uttar Pradesh</p>
              <p>📞 Arush Saxena: 8052995068</p>
              <p>📞 Tanush Bhardwaj: +91 7599 766 798</p>
            </div>
          </div>
        </section>
      </div>
    </div>
  )
}
